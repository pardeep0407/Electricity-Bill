//
//  File.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
enum Gender {
    case MALE
    case FEMALE
}
class Electricitybill
    {
        var Customerid : Int?
        var customername : String?
        var Gender : Gender?
        var unitConsumed : Int?
        var totalBillAmount : Double?
}
 
